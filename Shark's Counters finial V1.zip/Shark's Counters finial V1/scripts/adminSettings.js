import { world, system } from "@minecraft/server";
import { ActionFormData, ModalFormData } from "@minecraft/server-ui";
import { showSettingsMenu } from "./main.js";
import { updateAllRatios } from "./ratio.js";

export {
    loadAdminConfig,
    saveAdminConfig,
    defaultAdminConfig,
    adminConfig
  };
  



  
// Dynamic property prefix
const ADMIN_CONFIG_PREFIX = "sharkCounters:adminConfig";

// Default single admin config object
const defaultAdminConfig = {
  adminItemIdentifier: "minecraft:allow",
  playerItemIdentifier: "minecraft:stick",
  requireAdminItemTag: true,
  requirePlayerItemTag: false,
  adminItemTag: "admin",
  playerItemTag: "",
  adminNameList: [],
  banList: [],
  banKick: true,
  banCommand: "",
  softBanList: [],
  softBanTeleport: true,
  softBanTeleportCoords: { x: 0, y: 0, z: 0 },
  softBanAreaX: { min: 0, max: 0 },
  softBanAreaY: { min: 0, max: 0 },
  softBanAreaZ: { min: 0, max: 0 },
  softBanCommand: "",
  knownPlayers: [],
  ownerList: [],
  scoreDisplayList: [],
  scoreDisplayListEnabled: true,
  scoreDisplayListDelay: 15,
  scoreDisplaySidebar: [],
  scoreDisplaySidebarEnabled: true,
  scoreDisplaySidebarDelay: 15,
  scoreDisplayBelowName: [],
  scoreDisplayBelowNameEnabled: true,
  scoreDisplayBelowNameDelay: 15
};


const adminConfig = { ...defaultAdminConfig };


function loadAdminConfig() {
  let parsed = {};
  const raw = world.getDynamicProperty(ADMIN_CONFIG_PREFIX);
  if (raw) {
    try {
      parsed = JSON.parse(raw);
    } catch (e) {
      console.error("Failed to parse adminConfig:", e);
      parsed = {};
    }
  }
  // Merge saved → default so missing keys (like knownPlayers) get added
  return { ...defaultAdminConfig, ...parsed };
}

/**
 * Save the adminConfig object to dynamic properties.
 * @param {Object} config
 */
function saveAdminConfig(config) {
  try {
    world.setDynamicProperty(ADMIN_CONFIG_PREFIX, JSON.stringify(config));
  } catch (e) {
    console.error("[AdminSettings] failed to save config:", e);
  }
}


//-----------------------Item Settings Menu-----------------------
export function showEditItemSettingsForm(player) {
  const cfg = loadAdminConfig() || defaultAdminConfig;

  new ModalFormData()
    .title("Item Settings")
    .textField("Admin Item Identifier", "Enter item identifier", cfg.adminItemIdentifier)
    .textField("Player Item Identifier", "Enter player item identifier", cfg.playerItemIdentifier)
    .toggle("Require Admin Item Tag", cfg.requireAdminItemTag)
    .toggle("Require Player Item Tag", cfg.requirePlayerItemTag)
    .textField("Admin Item Tag", "Enter admin item tag", cfg.adminItemTag)
    .textField("Player Item Tag", "Enter player item tag", cfg.playerItemTag)
    .show(player)
    .then(res => {
      if (res.canceled) return;
      const [
        adminId,
        playerId,
        requireAdmin,
        requirePlayer,
        adminTag,
        playerTag
      ] = res.formValues;

      const newCfg = {
        ...cfg,
        adminItemIdentifier:    adminId.trim()    || defaultAdminConfig.adminItemIdentifier,
        playerItemIdentifier:   playerId.trim()   || defaultAdminConfig.playerItemIdentifier,
        requireAdminItemTag:    requireAdmin,
        requirePlayerItemTag:   requirePlayer,
        adminItemTag:           adminTag.trim()   || defaultAdminConfig.adminItemTag,
        playerItemTag:          playerTag.trim()  || defaultAdminConfig.playerItemTag,
        // leave cfg.adminNameList untouched here
      };

      saveAdminConfig(newCfg);
      player.sendMessage("Item settings saved.");
    });
}

export async function showAdminSettings(player) {
  // 1) load config (with defaults)
  const cfg          = loadAdminConfig() || defaultAdminConfig;
  const knownPlayers = cfg.knownPlayers || [];

  // Admin lists
  const ownerList       = cfg.ownerList       || [];
  const adminList       = cfg.adminNameList   || [];
  const currentAdmins   = [...ownerList, ...adminList];
  const addAdminList    = knownPlayers.filter(n => !currentAdmins.includes(n));
  const removeAdminList = adminList.filter(n => !ownerList.includes(n));

  // Owner lists
  const currentOwners   = ownerList;
  const addOwnerList    = knownPlayers.filter(n => !ownerList.includes(n));
  const removeOwnerList = ownerList;

  // 2) build placeholder-backed option arrays
  const addAdminOptions    = addAdminList.length    ? ["Select a player", ...addAdminList]    : ["<no one available>"];
  const removeAdminOptions = removeAdminList.length ? ["Select a player", ...removeAdminList] : ["<none to remove>"];
  const addOwnerOptions    = addOwnerList.length    ? ["Select a player", ...addOwnerList]    : ["<no one available>"];
  const removeOwnerOptions = removeOwnerList.length ? ["Select a player", ...removeOwnerList] : ["<none to remove>"];

  // 3) build form
  const form = new ModalFormData()
    .title("Admin Settings")

    // — Admin section —
    .dropdown(
      "Current Admins (menu permisions)",
      currentAdmins.length ? currentAdmins : ["<none>"]
    )
    .dropdown("Add Admin",    addAdminOptions)
    .dropdown("Remove Admin", removeAdminOptions)
    .textField("Enter custom admin name", "Any name not in knownPlayers", "")

    // — Owner section —
    .dropdown(
      "Current Owners (full permissions to view even this menu)",
      currentOwners.length ? currentOwners : ["<none>"]
    )
    .dropdown("Add Owner",    addOwnerOptions)
    .dropdown("Remove Owner", removeOwnerOptions)
    .textField("Enter custom owner name", "Any name not in knownPlayers", "");

  // 4) show + bail if canceled
  const res = await form.show(player);
  if (res.canceled || !res.formValues) return;

  // 5) unpack indices & names
  const [
    /*curAdmin*/, addAdminIdx, remAdminIdx, customAdminName,
    /*curOwner*/, addOwnerIdx, remOwnerIdx, customOwnerName
  ] = res.formValues;

  // 6) apply Admin changes only if index > 0
  if (addAdminIdx > 0) {
    const toAdd = addAdminList[addAdminIdx - 1];
    if (cfg.adminNameList.includes(toAdd)) {
      player.sendMessage(`§c${toAdd} is already an admin.`);
      return;
    }
    if (!cfg.adminNameList.includes(toAdd)) {  
      cfg.adminNameList.push(toAdd);
    player.sendMessage(`§aAdded ${toAdd} as admin.`);
    }
    }
  if (remAdminIdx > 0) {
    const toRemove = removeAdminList[remAdminIdx - 1];
    cfg.adminNameList = cfg.adminNameList.filter(n => n !== toRemove);
    player.sendMessage(`§cRemoved ${toRemove} from admins.`);
  }
  const customAdmin = customAdminName.trim();
  if (customAdmin) {
    if (!cfg.adminNameList.includes(customAdmin)) {
      cfg.adminNameList.push(customAdmin);
    player.sendMessage(`§aAdded custom admin: ${customAdmin}.`);
    }
    if (cfg.adminNameList.includes(customAdmin)) { 
      player.sendMessage(`§cCustom admin ${customAdmin} already is in list.`);
    }
  }

  // 7) apply Owner changes only if index > 0
  if (addOwnerIdx > 0) {
    const toAddOwner = addOwnerList[addOwnerIdx - 1];
    if (cfg.ownerList.includes(toAddOwner)) {
      player.sendMessage(`§c${toAddOwner} is already an owner.`);
      return;
    }
    if (!cfg.ownerList.includes(toAddOwner)) {
    cfg.ownerList.push(toAddOwner);
    player.sendMessage(`§aAdded ${toAddOwner} as owner.`);
    }
  }
  if (remOwnerIdx > 0) {
    const toRemoveOwner = removeOwnerList[remOwnerIdx - 1];
    cfg.ownerList = cfg.ownerList.filter(n => n !== toRemoveOwner);
    player.sendMessage(`§cRemoved ${toRemoveOwner} from owners.`);
  }
  const customOwner = customOwnerName.trim();
  if (customOwner) {
    if (!cfg.ownerList.includes(customOwner)) {
       cfg.ownerList.push(customOwner);
      
    player.sendMessage(`§aAdded custom owner: ${customOwner}.`);
    }
    if (cfg.ownerList.includes(customOwner)) { 
      player.sendMessage(`§cCustom owner ${customOwner} already is in list.`);
    }
  }

  // 8) persist
  saveAdminConfig(cfg);
}

//------------------------------------Score Display Menu--------------------------------
export async function showScoreDisplaySettingsMenu(player) {
  const form = new ActionFormData()
    .title("Score Display Settings")
    .body("Choose which display slot to configure:")
    .button("List Display Settings")
    .button("Sidebar Display Settings")
    .button("Below-Name Display Settings");

  const res = await form.show(player);
  if (res.canceled) return;

  switch (res.selection) {
    case 0: return showScoreDisplayListMenu(player);
    case 1: return showScoreDisplaySidebarMenu(player);
    case 2: return showScoreDisplayBelowNameMenu(player);
  }
}


export async function showScoreDisplayListMenu(player) {
  const cfg = loadAdminConfig() || defaultAdminConfig;
  const listArr = Array.isArray(cfg.scoreDisplayList) ? cfg.scoreDisplayList : [];

  const form = new ModalFormData()
    .title("List Display Settings")
    .toggle("List Display Enabled", Boolean(cfg.scoreDisplayListEnabled))
    .textField("Objectives (e.g. kills,deaths)", listArr.join(", "))
    .textField("Delay (seconds)", (cfg.scoreDisplayListDelay ?? 15).toString());

  const res = await form.show(player);
  if (res.canceled || !res.formValues) return;

  const [enabledRaw, objTextRaw, delayTextRaw] = res.formValues;
  const enabled = Boolean(enabledRaw);
  const objList = objTextRaw?.trim()
    ? objTextRaw.split(",").map(s => s.trim()).filter(Boolean)
    : cfg.scoreDisplayList;

  const delay = (() => {
    const val = parseInt((delayTextRaw ?? "").trim(), 10);
    return isNaN(val) || val <= 0 ? cfg.scoreDisplayListDelay ?? 15 : val;
  })();

  const updated = {
    ...cfg,
    scoreDisplayListEnabled: enabled,
    scoreDisplayList: objList,
    scoreDisplayListDelay: delay
  };

  saveAdminConfig(updated);
  player.sendMessage("§aList display settings saved.");
}


export async function showScoreDisplaySidebarMenu(player) {
  const cfg = loadAdminConfig() || defaultAdminConfig;
  const sidebarArr = Array.isArray(cfg.scoreDisplaySidebar) ? cfg.scoreDisplaySidebar : [];

  const form = new ModalFormData()
    .title("Sidebar Display Settings")
    .toggle("Sidebar Display Enabled", Boolean(cfg.scoreDisplaySidebarEnabled))
    .textField("Objectives (e.g. kills,deaths)", sidebarArr.join(", "))
    .textField("Delay (seconds)", (cfg.scoreDisplaySidebarDelay ?? 15).toString());

  const res = await form.show(player);
  if (res.canceled || !res.formValues) return;

  const [enabledRaw, objTextRaw, delayTextRaw] = res.formValues;
  const enabled = Boolean(enabledRaw);
  const objList = objTextRaw?.trim()
    ? objTextRaw.split(",").map(s => s.trim()).filter(Boolean)
    : cfg.scoreDisplaySidebar;

  const delay = (() => {
    const val = parseInt((delayTextRaw ?? "").trim(), 10);
    return isNaN(val) || val <= 0 ? cfg.scoreDisplaySidebarDelay ?? 15 : val;
  })();

  const updated = {
    ...cfg,
    scoreDisplaySidebarEnabled: enabled,
    scoreDisplaySidebar: objList,
    scoreDisplaySidebarDelay: delay
  };

  saveAdminConfig(updated);
  player.sendMessage("§aSidebar display settings saved.");
}


export async function showScoreDisplayBelowNameMenu(player) {
  const cfg = loadAdminConfig() || defaultAdminConfig;
  const belowArr = Array.isArray(cfg.scoreDisplayBelowName) ? cfg.scoreDisplayBelowName : [];

  const form = new ModalFormData()
    .title("Below-Name Display Settings")
    .toggle("Below-Name Display Enabled", Boolean(cfg.scoreDisplayBelowNameEnabled))
    .textField("Objectives (e.g. kills,deaths)", belowArr.join(", "))
    .textField("Delay (seconds)", (cfg.scoreDisplayBelowNameDelay ?? 15).toString());

  const res = await form.show(player);
  if (res.canceled || !res.formValues) return;

  const [enabledRaw, objTextRaw, delayTextRaw] = res.formValues;
  const enabled = Boolean(enabledRaw);
  const objList = objTextRaw?.trim()
    ? objTextRaw.split(",").map(s => s.trim()).filter(Boolean)
    : cfg.scoreDisplayBelowName;

  const delay = (() => {
    const val = parseInt((delayTextRaw ?? "").trim(), 10);
    return isNaN(val) || val <= 0 ? cfg.scoreDisplayBelowNameDelay ?? 15 : val;
  })();

  const updated = {
    ...cfg,
    scoreDisplayBelowNameEnabled: enabled,
    scoreDisplayBelowName: objList,
    scoreDisplayBelowNameDelay: delay
  };

  saveAdminConfig(updated);
  player.sendMessage("§aBelow-name display settings saved.");
}


//---------------------------------------------------------------------------

//--------------------------Score Display Loops------------------------------
let listCounter = 0;
let listIndex = 0;

let sidebarCounter = 0;
let sidebarIndex = 0;

let belowNameCounter = 0;
let belowNameIndex = 0;

// Updated helper function — now accepts full display objective name
function updateDisplayObjective(overworld, raw, targetDisplayId) {
  const baseId = raw.replace(/§./g, "").toLowerCase(); // stripped version
  const colorCodes = (raw.match(/§./g) || []).join("");
  const displayName = colorCodes +
    baseId.charAt(0).toUpperCase() +
    baseId.slice(1);

  // Remove and re-add the correct per-slot display objective
  overworld.runCommand(`scoreboard objectives remove "${targetDisplayId}"`);
  overworld.runCommand(`scoreboard objectives add "${targetDisplayId}" dummy "${displayName}"`);
  overworld.runCommand(`execute as @a run scoreboard players operation @s "${targetDisplayId}" = @s ${baseId}`);
   
}


system.runInterval(() => {
  const cfg = loadAdminConfig() || defaultAdminConfig;
  const overworld = world.getDimension("overworld");
  

  updateAllRatios(); // Optional utility if you're rotating action bar stats

  // ─── LIST SLOT ────────────────────────────────────────────────────────────
  if (cfg.scoreDisplayListEnabled) {
    const arr = Array.isArray(cfg.scoreDisplayList) ? cfg.scoreDisplayList : [];
    const delay = cfg.scoreDisplayListDelay ?? 15;
    if (arr.length > 0) {
      listCounter++;
      if (listCounter >= delay) {
        const raw = arr[listIndex % arr.length];
        const idNoColor = raw.replace(/§./g, "").toLowerCase();
        const displayId = `${idNoColor}_list_display`;

        updateDisplayObjective(overworld, raw, displayId);
        overworld.runCommand(`scoreboard objectives setdisplay list "${displayId}"`);

        listIndex = (listIndex + 1) % arr.length;
        listCounter = 0;
      }
    }
  }

  // ─── SIDEBAR SLOT ─────────────────────────────────────────────────────────
  if (cfg.scoreDisplaySidebarEnabled) {
    const arr = Array.isArray(cfg.scoreDisplaySidebar) ? cfg.scoreDisplaySidebar : [];
    const delay = cfg.scoreDisplaySidebarDelay ?? 15;
    if (arr.length > 0) {
      sidebarCounter++;
      if (sidebarCounter >= delay) {
        const raw = arr[sidebarIndex % arr.length];
        const idNoColor = raw.replace(/§./g, "").toLowerCase();
        const displayId = `${idNoColor}_sidebar_display`;

        updateDisplayObjective(overworld, raw, displayId);
        overworld.runCommand(`scoreboard objectives setdisplay sidebar "${displayId}"`);

        sidebarIndex = (sidebarIndex + 1) % arr.length;
        sidebarCounter = 0;
      }
    }
  }

  // ─── BELOW-NAME SLOT ──────────────────────────────────────────────────────
  if (cfg.scoreDisplayBelowNameEnabled) {
    const arr = Array.isArray(cfg.scoreDisplayBelowName) ? cfg.scoreDisplayBelowName : [];
    const delay = cfg.scoreDisplayBelowNameDelay ?? 15;
    if (arr.length > 0) {
      belowNameCounter++;
      if (belowNameCounter >= delay) {
        const raw = arr[belowNameIndex % arr.length];
        const idNoColor = raw.replace(/§./g, "").toLowerCase();
        const displayId = `${idNoColor}_below_display`;

        updateDisplayObjective(overworld, raw, displayId);
        overworld.runCommand(`scoreboard objectives setdisplay belowname "${displayId}"`);

        belowNameIndex = (belowNameIndex + 1) % arr.length;
        belowNameCounter = 0;
      }
    }
  }

}, 20); // runs every second
